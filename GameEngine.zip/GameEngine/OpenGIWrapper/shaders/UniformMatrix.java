package shaders;
 
import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Matrix4f;
 
public class UniformMatrix extends Uniform{
     
    private float currentValue;
    private boolean used = false;
     
    public UniformMatrix(String name){
        super(name);
    }
     
    public void loadFloat(float value){
        if(!used || currentValue!=value){
            GL20.glUniform1f(super.getLocation(), value);
            used = true;
            currentValue = value;
        }
    }

	public void loadMatrix(Matrix4f projectionViewMatrix) {
		// TODO Auto-generated method stub
		
	}
 
}