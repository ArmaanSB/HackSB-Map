package indicesGenerators;
 
 
public interface IndicesGenerator {
     
    public int[] generateIndexBuffer(int vertexCount);
 
}