package openglObjects;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import opengIObjects.Attribute;

public class Vao {

	public void bind() {
		// TODO Auto-generated method stub
		
	}

	public void unbind() {
		// TODO Auto-generated method stub
		
	}

	public void delete(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public static Vao create() {
		// TODO Auto-generated method stub
		return null;
	}

	public void initDataFeed(ByteBuffer buffer, int glStaticDraw, Attribute attribute, Attribute attribute2) {
		// TODO Auto-generated method stub
		
	}

	public void createIndexBuffer(IntBuffer intBuffer) {
		// TODO Auto-generated method stub
		
	}

}
