package main;

public class geomGenerator {

}
